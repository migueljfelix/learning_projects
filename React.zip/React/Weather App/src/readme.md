React Weather app with the help of the freecodecamp.org tutorial.

APIs used:
OpenWeather API
GeoDb Api

Packages used:
React-Accordion
React-select-async-paginate