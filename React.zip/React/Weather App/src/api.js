export const GeoApiOptions = {
	method: 'GET',
	headers: {
		'X-RapidAPI-Key': 'fb6f37ac4emshcd46ed697a7070bp197964jsn925c270ab616',
		'X-RapidAPI-Host': 'wft-geo-db.p.rapidapi.com'
	}
};

export const Geo_API_URL ="https://wft-geo-db.p.rapidapi.com/v1/geo";

export const WEATHER_API_URL ="https://api.openweathermap.org/data/2.5";

export const WEATHER_API_KEY ="6042ad5fa9901153183466601d1d9215";