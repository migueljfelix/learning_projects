
function Comments(props){
    return (
        <div>
            <p>{props.date}</p>
            <hr/>
        </div>
    )
    }

export default Author_date;