import './menu.css';

function menu(props){
    return (
        <div>
            <nav className="menubar"><h4>{props.blogtitle}</h4></nav>
        </div>
    )
    }

export default menu;