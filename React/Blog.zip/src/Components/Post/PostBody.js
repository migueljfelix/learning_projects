
function Postbody(props){
    return (
        <div>
            <p>{props.body}</p>
            <img>{props.image}</img>
        </div>
    )
    }

export default Postbody;