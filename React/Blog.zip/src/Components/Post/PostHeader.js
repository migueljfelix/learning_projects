import Author_date from './Author_Date' ;

function PostHeader(props){
    return (
        <div>
            <h2>{props.title}</h2>
            <p>{props.subheader}</p>
            <Author_date author="João António" date="18.30, 2 Janeiro"/>
        </div>
    )
    }

export default PostHeader;