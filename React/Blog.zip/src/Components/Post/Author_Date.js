import './author_date.css';

function Author_date(props){
    return (
        <div>
            <div className="author_date">
            <p>{props.author}</p>
            <p>{props.date}</p>
            </div>
            <hr/>
        </div>
    )
    }

export default Author_date;