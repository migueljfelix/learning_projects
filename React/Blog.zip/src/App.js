import './App.css';
import PostHeader from './Components/Post/PostHeader';
import Author_Date from './Components/Post/Author_Date';
import Postbody from './Components/Post/PostBody';
import React, { useEffect, useState } from 'react';
import { render } from '@testing-library/react';
import menu from './Components/Menu/Menu';

class Post extends React.Component {

    constructor(props){
      super(props);
      
      this.state = {
        title: props.title,
        body: props.body
      }

    }
    //para fazer o fetch, para correr depois do codigo ser montado
    componentDidMount() {
        fetch('https://jsonplaceholder.typicode.com/posts/1')
        .then((response) => response.json())
        .then(json => {
          this.setState({title: json.title, body: json.body});
        });

      }
/* link to (procurar) */
  render(){
  return (
    <div className="main">
      <div className="post_header">
        <PostHeader title= {this.state.title} subheader= "This is the subheading and should be two sentences"/>
        <Postbody body={this.state.body} img="this should be the source"/>
      </div>
      <div className="sidebar">
        <h2>About Me </h2>
        <img className="image" src="https://www.kindpng.com/picc/m/76-763396_emotions-clipart-general-psychology-robot-head-black-and.png"/>
        <p>Bleep bloop I am a robot and I just made this blog..</p>
      </div>
    </div>
  );
}
}
//https://jsonplaceholder.typicode.com/
export default Post;




  
    
   